public class Calculator 
{
	public int divide(int num)
	{
		
		return (100/num);
	}
}
