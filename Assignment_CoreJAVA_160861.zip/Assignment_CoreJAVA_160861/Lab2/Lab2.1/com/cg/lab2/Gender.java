package com.cg.lab2;

public enum Gender {
M,F;
}
