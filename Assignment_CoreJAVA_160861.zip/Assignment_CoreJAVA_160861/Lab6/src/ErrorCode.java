

public class ErrorCode {

}
