package com.cg.mypaymentapp.main;

import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Client {
	static Scanner sc;
	public static void main(String[] args) {
		
		WalletService service=new WalletServiceImpl();
		
		
		 sc=new Scanner(System.in);
		int ch=0;
		
		do{
			System.out.println("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
			System.out.println("		Mobile Wallet				");
			System.out.println("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
			System.out.println(" 1.Create Account");
			System.out.println(" 2.Show Balance");
			System.out.println(" 3.Deposit");
			System.out.println(" 4.Withdraw");
			System.out.println(" 5.Fund Transfer");
			System.out.println(" 6.Fund Transcations");
			
			//System.out.println("7.Close App");
			System.out.println("\nEnter Your Choice :\n");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				System.out.println("Please Enter Your Mobile Number");
				String custMobNo=sc.next();
				System.out.println("Please Enter Your Name");
				String custName=sc.next();
				System.out.println("Please Enter Money you wanted to add");
				BigDecimal money=sc.nextBigDecimal();
						
				try {
					if(service.ValidateMobNo(custMobNo)&&service.ValidateName(custName)&&service.ValidateAmount(money)){
						Customer cust = null;
						try {
							cust = service.createAccount(custName, custMobNo, money);
						} catch (InvalidInputException e) {
							// TODO Auto-generated catch block
							
						}
						if(cust!=null)
							System.out.println(cust);
						else
							System.out.println("Account didnot added in database");
						
					} else
						try {
							throw new InvalidInputException("Enter Details of Required Format");
						} catch (InvalidInputException e) {
							// TODO Auto-generated catch block
							
						}
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					
				}
				
				break;
			
			case 2:
				System.out.println("Please Enter Your Mobile Number");
				String custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
						Customer customer=service.showBalance(custMobNo1);
						
							Wallet w=customer.getWallet();
							System.out.println("Hi "+customer.getName()+", your balance is "+w.getBalance() +" !!");
									
						}
					else
						throw new InvalidInputException("Enter Ten Digit Number starting with 6/7/8/9  ");
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e);
				}
				
				
				break;
				
			
			case 3:
				System.out.println("Please Enter Your Mobile Number");
				custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
					 Customer customer=service.showBalance(custMobNo1);
					 Wallet w=customer.getWallet();
					 System.out.println("Hi "+customer.getName()+", your current balance is "+w.getBalance() +" !!");
					 System.out.println("Please Enter the amount you want to deposit ");
					 BigDecimal dep=sc.nextBigDecimal();
					 customer=service.depositAmount(custMobNo1, dep);
					 w=customer.getWallet();
					 System.out.println("Hi "+customer.getName()+", your updated balance is "+w.getBalance() +" !!");
					}
					else
						throw new InvalidInputException("Enter  Ten Digit Mobile Number  ");
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					
				}
					
				 break;
				 
			case 4:
				System.out.println("Please Enter Your Mobile Number");
				custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
					 Customer customer=service.showBalance(custMobNo1);
					 Wallet w=customer.getWallet();
					 System.out.println("Hi "+customer.getName()+", your current balance is "+w.getBalance() +"  !!");
					 System.out.println("Please Enter the amount you want to withdraw ");
					 BigDecimal withdraw=sc.nextBigDecimal();
					 try {
						customer=service.withdrawAmount(custMobNo1, withdraw);
					} catch (InsufficientBalanceException e) {
						// TODO Auto-generated catch block
						
					}
					 w=customer.getWallet();
					 System.out.println("Hi "+customer.getName()+", your updated balance is "+w.getBalance() +"  !!");
					}
					else 
						throw new InvalidInputException("Enter Ten Digit Mobile Number  ");
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
				
				}
				 break;
				 
				 
			case 5:
				System.out.println("Please Enter Your Mobile Number");
				String custMobNoS=sc.next();
				try {
					if(service.ValidateMobNo(custMobNoS)){
						Customer customer=service.showBalance(custMobNoS);
						Wallet w=customer.getWallet();
						System.out.println("Hi "+customer.getName()+", your current balance is "+w.getBalance() +"  !!");
						System.out.println("Please Enter the mobile number  you want to transfer money ");
						String custMobNoT=sc.next();
						if(service.ValidateMobNo(custMobNoT)){
						System.out.println("Please Enter amount to be transferred ");
						
						BigDecimal ft=sc.nextBigDecimal();
					 
						customer=service.fundTransfer(custMobNoS, custMobNoT, ft);
						w=customer.getWallet();
						System.out.println("Hi "+customer.getName()+", your updated balance is "+w.getBalance() +"  !!");
					} }
					else
						try {
							throw new InvalidInputException("Enter Ten Digit Mobile Number  ");
						} catch (InvalidInputException e) {
							// TODO Auto-generated catch block
						
						}
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					
				}
				
				 break;
				 
			case 6:
				WalletServiceImpl se=new WalletServiceImpl();
				String[] trans=se.getDep();
				for(String tran:trans)
				System.out.println(tran);
				break;
			}
			
		}while(ch!=7);
		
System.out.println("Thank You !!");
	}

}
