package com.cg.mypaymentapp.service;
import java.math.BigDecimal;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;


public interface WalletService {
public Customer createAccount(String name ,String mobileno, BigDecimal amount) throws InvalidInputException;
public Customer showBalance (String mobileno) throws InvalidInputException;
public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount) throws InvalidInputException;
public Customer depositAmount (String mobileNo,BigDecimal amount ) throws InvalidInputException;
public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientBalanceException, InvalidInputException;


public boolean ValidateName(String name) throws InvalidInputException;
public boolean ValidateMobNo(String MobNo) throws InvalidInputException;
public boolean ValidateAmount(BigDecimal amount) throws InvalidInputException;


}
