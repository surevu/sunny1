package com.cg.mobshop.ui;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobshop.dao.PurchaseDetailsDaoImpl;
import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;
import com.cg.mobshop.service.PurchaseService;
import com.cg.mobshop.service.PurchaseServiceImpl;


public class Client {

	public static void main(String[] args) throws PurchaseException {
		int ch=0;
		Scanner sc= new Scanner(System.in);
	//	PurchaseDetails pd= new PurchaseDetails();
		PurchaseService service= new PurchaseServiceImpl();
		do{
			System.out.println("\n-----------------------------\n Welcome to Smallc mobiles\n-----------------------------\n1. Add Purchase Details\n2. Display MobileList\n3. Display Mobile List between given price range\n4. Update Mobile Details\n5. Exit\nEnter Your Choice");

			ch=sc.nextInt();
			switch(ch){
			
			
			case 1:
		System.out.println("Enter Customer name ");
		String name= sc.next();
		System.out.println("Enter phone no ");
		String phn= sc.next();
		System.out.println("Enter mail id ");
		String mail= sc.next();
		System.out.println("Enter mobile id ");
		int mobid= sc.nextInt();
		
		PurchaseDetails pd= new PurchaseDetails();
		pd.setCustName(name);
		pd.setMailId(mail);
		pd.setMobileId(mobid);
		pd.setPhoneNo(phn);
		try {
			if( service.ValidateDetails(pd)!=null){
				System.out.println("valid details");
				}
			else
			{				System.out.println("Invalid details entered...");
			break;
			}
		} catch (PurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int purchaseid = service.addPurchaseDetails(pd);
		System.out.println("Record inserted..."+purchaseid);
	
	
		
		break;
			case 2:
				ArrayList<Mobile> list=service.getMobileList();
				if(list.size()==0)
					System.out.println("No record found");
				else
				{
					for(Mobile m:list){
						System.out.print(m.getMobileId()+"\t");
						//System.out.print(m.getMobileName()+"\t");
						System.out.print(m.getPrice()+"\t\t");
						System.out.print(m.getQuantity()+"\t");
						System.out.print(m.getName()+"\n");
					}
				}
				
				
				break;
			case 3:
				
				System.out.println("enter min value");
				double min=sc.nextInt();
				System.out.println("enter max value");
				double max=sc.nextInt();
				ArrayList<Mobile> list1=service.getMobileList(min,max);
				if(list1.size()==0)
					System.out.println("no mobile in given range");
				else
				{
					for(Mobile m:list1){
						System.out.print(m.getMobileId()+"\t");
						//System.out.print(m.getMobileName()+"\t");
						System.out.print(m.getPrice()+"\t\t");
						System.out.print(m.getQuantity()+"\t");
						System.out.print(m.getName()+"\n");
					}
				}
				
				
				
				
				break;
			case 4:
			System.out.println("Enter mobile id : ");
			int mid=sc.nextInt();
			
			System.out.println("Enter price : ");
			int pri=sc.nextInt();
			
			System.out.println("Enter quantity : ");
			int qty=sc.nextInt();
			Mobile mobile=new Mobile();
			mobile.setMobileId(mid);
			mobile.setPrice(pri);
			mobile.setQuantity(qty);
			mobile=service.updateMobileDetails(mobile);
			if(mobile!=null)
				System.out.println("mobile details added successfully");
			
			
			break;
				
		
		}
		}while(ch!=5);
		/*
		ArrayList<Mobile> list= service.getMobileList();
		if(list.size()==0){
			System.err.println("No record Found");
		}
		else{
			for(Mobile mob : list){
				System.out.print(mob.getMobileId()+" ");
				System.out.print(mob.getName()+" " );
				System.out.print(mob.getQuantity()+" ");
			System.out.println(mob.getPrice());
			}
		}*/
		
		/*
		System.out.println("Enter Mobile id : ");
		int mobid= sc.nextInt();
		System.out.println("Enter Price");
		double pr= sc.nextDouble();
		System.out.println("Enter quantity ");
		int quantity= sc.nextInt();
		Mobile mobile= new Mobile ();
		mobile.setMobileId(mobid);
		mobile.setPrice(pr);
		mobile.setQuantity(quantity);
		
		try {
			mobile= service.updateMobileDetails(mobile);
			if(mobile!=null)
				System.out.println("Mobile details updated successfully.");
				
		} catch (PurchaseException e) {
		System.out.println(e.getMessage());
		}
		*/
		
		
		
		
		
		
		
		
		
}
}
