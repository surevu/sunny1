package com.cg.springmvcdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemo.dto.Mobile;
import com.cg.springmvcdemo.service.IMobileSerice;


@Controller
public class MobController {
	@Autowired
	IMobileSerice mobileservice;
	
	@RequestMapping(value="addMobile")
	public ModelAndView showAll(){
		List<Mobile> allMobile=mobileservice.showAllMobile();
		System.out.println(allMobile);
		
		
		return new ModelAndView("addMobile11", "data",allMobile);
	}
	
	
	
	
}
