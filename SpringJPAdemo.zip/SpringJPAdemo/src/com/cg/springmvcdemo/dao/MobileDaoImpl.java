package com.cg.springmvcdemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemo.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao{
	
	
	@PersistenceContext
	EntityManager em;
	

	@Override
	public void addMobile(Mobile mobile) {
		// TODO Auto-generated method stub
		em.persist(mobile);
		em.flush();
		
		
	}

	@Override
	public List<Mobile> showAllMobile() {
		
		
		Query query= em.createQuery("FROM Mobile");
		List<Mobile> list=query.getResultList();
		return list;
		
	}

	@Override
	public void deleteMobile(int mobId) {
		Query querySearch =em.createQuery("DELETE Mobile WHERE mobId=:mobdata1");
		querySearch.setParameter("mobdata1", mobId);
		querySearch.executeUpdate();
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mobile searchMobile(int mobId) {
		
		Query querySearch =em.createQuery("FROM Mobile WHERE mobId=:mobdata");
		querySearch.setParameter("mobdata", mobId);
		Mobile mobSearch=(Mobile) querySearch.getResultList().get(0);
		
		
		
		return mobSearch;
	}

	@Override
	public Mobile updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		return null;
	}

}
