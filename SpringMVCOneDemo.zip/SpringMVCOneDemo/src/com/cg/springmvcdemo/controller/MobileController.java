package com.cg.springmvcdemo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemo.dto.Mobile;
import com.cg.springmvcdemo.service.IMobileSerice;


@Controller
public class MobileController {
	
	@Autowired
	IMobileSerice mobileservice;
	
	@RequestMapping(value="/home")
	public String getAllMobiles(@ModelAttribute("my") Mobile mob,Map<String,Object> map){
		
		List<String> myList=new ArrayList<>();
		List<String> myList1=new ArrayList<>();
		myList.add("Android");
		myList.add("Windows");
		myList.add("iPhone");
		myList1.add("yes");
		myList1.add("no");
		
		map.put("category",myList);
		map.put("online",myList1);
		
		return "AddMobile";
		
	}
	
	@RequestMapping(value="addData",method=RequestMethod.POST)   //always write post beacause bydefault it is get
	public String addMobileData(@Valid@ModelAttribute("my") Mobile mobile,BindingResult res,Map<String,Object> map){
		if(res.hasErrors()){
			List<String> myList=new ArrayList<>();
			List<String> myList1=new ArrayList<>();
			myList.add("Android");
			myList.add("Windows");
			myList.add("iPhone");
			myList1.add("yes");
			myList1.add("no");
			
			map.put("category",myList);
			map.put("online",myList1);
			return "AddMobile";
		}
		
			else{	
		mobileservice.addMobile(mobile);
		//System.out.println(mobile.getMobId()+"  "+mobile.getMobName()+"  "+mobile.getMobPrice()+"  "+mobile.getMobCategory()+ " "+mobile.getOnlineAvailable()+ "......");
		return "success";
			}
	}
	
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView showAllMobileData(@ModelAttribute("pu") Mobile mob){
		
		List<Mobile> allMobile=mobileservice.showAllMobile();
		System.out.println(allMobile);
		
		return new ModelAndView("mobileshow", "data",allMobile);
	}
	@RequestMapping(value="searchmobile",method=RequestMethod.GET)
	public String searchData(@ModelAttribute("yy") Mobile mob){
		return "searchmobile";
		}
	@RequestMapping(value="mobilesearch",method=RequestMethod.POST)
	public ModelAndView dataSearch(@ModelAttribute("yy") Mobile mob){
		
		Mobile mob1=mobileservice.searchMobile(mob.getMobId());
		System.out.println(mob1);
		
		return new ModelAndView("showsearchmobile", "temp",mob1);
			}
	@RequestMapping(value="deletemobile", method=RequestMethod.GET)
	public String deleteMobile(@ModelAttribute("dy") Mobile mob2){
		return "deletemob";
		
	}
	
	@RequestMapping(value="delmob",method=RequestMethod.POST)
	public String datadel(@ModelAttribute("dy") Mobile mob2){
		
		mobileservice.deleteMobile(mob2.getMobId());
		
		
		return "deletepage";
		}
	
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String updateData(@ModelAttribute("up") Mobile mob){
		return "updatemobile";
		
	}
	@RequestMapping(value="updatesuccess",method=RequestMethod.POST)
	public String update2(@ModelAttribute("up") Mobile mob){
		
		Mobile mob1=mobileservice.updateMobile(mob);
		System.out.println(mob);
		
		return "updatesuccess";
			}
	
	
	
	@RequestMapping(value="purchase")
	public ModelAndView purchase(@ModelAttribute("pu") Mobile mob){
		
		
	return new ModelAndView("purchase", "temp",mob);
	}
	
}
	
