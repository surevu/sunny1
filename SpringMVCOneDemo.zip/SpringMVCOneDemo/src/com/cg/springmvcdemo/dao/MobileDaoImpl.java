package com.cg.springmvcdemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemo.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao{
	
	
	@PersistenceContext
	EntityManager em;
	

	@Override
	public void addMobile(Mobile mobile) {
		// TODO Auto-generated method stub
		em.persist(mobile);
		em.flush();
		
		
	}

	@Override
	public List<Mobile> showAllMobile() {
		
		
		Query query= em.createQuery("FROM Mobile");
		List<Mobile> list=query.getResultList();
		return list;
		
	}

	@Override
	public void deleteMobile(int mobId) {
		Query querySearch =em.createQuery("DELETE Mobile WHERE mobId=:mobdata1");
		querySearch.setParameter("mobdata1", mobId);
		querySearch.executeUpdate();
		// TODO Auto-generated method stub
		
	}

	@Override
	public Mobile searchMobile(int mobId) {
		
		Query querySearch =em.createQuery("FROM Mobile WHERE mobId=:mobdata");
		querySearch.setParameter("mobdata", mobId);
		Mobile mobSearch=(Mobile) querySearch.getResultList().get(0);
		
		
		
		return mobSearch;
	}

	@Override
	public Mobile updateMobile(Mobile mob) {
		
		Query querySearch =em.createQuery("UPDATE Mobile  SET mobName=:mn, mobPrice=:mp  WHERE mobId=:mobdata1");
		//Query querySearch =em.createQuery("FROM Mobile WHERE mobId=:mobdata1");
		querySearch.setParameter("mobdata1", mob.getMobId());
		querySearch.setParameter("mn", mob.getMobName());
		querySearch.setParameter("mp", mob.getMobPrice());
		//Mobile mobs=(Mobile) querySearch.getResultList().get(0);
		//mobs.setMobName(mob.getMobName());
		//mobs.setMobPrice(mob.getMobPrice());
		//em.persist(mobs);
		//em.flush();
		querySearch.executeUpdate();
		
		
		Query querySearch1 =em.createQuery("FROM Mobile WHERE mobId=:mobdata2");
		querySearch1.setParameter("mobdata2", mob.getMobId());
		Mobile mobSearch1=(Mobile) querySearch1.getResultList().get(0);
		
		// TODO Auto-generated method stub
		return mobSearch1;
	}

}
