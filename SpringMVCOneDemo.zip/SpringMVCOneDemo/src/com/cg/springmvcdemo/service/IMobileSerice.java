package com.cg.springmvcdemo.service;

import java.util.List;

import com.cg.springmvcdemo.dto.Mobile;

public interface IMobileSerice {
	
	public void addMobile(Mobile mobile);
	public List<Mobile> showAllMobile();
	public void deleteMobile(int mobId);
	public Mobile searchMobile(int mobId);
	public Mobile updateMobile(Mobile mob);
	
	

}
