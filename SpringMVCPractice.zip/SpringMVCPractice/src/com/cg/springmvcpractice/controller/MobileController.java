package com.cg.springmvcpractice.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MobileController {
	
	@RequestMapping(value="/hello")
	public String getMobDetails()
	{
		return "welcome";
	}

}
