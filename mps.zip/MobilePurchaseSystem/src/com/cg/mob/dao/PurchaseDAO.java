package com.cg.mob.dao;

import java.util.ArrayList;

import com.cg.mob.dto.Mobile;
import com.cg.mob.dto.PurchaseDetails;

public interface PurchaseDAO {
	
	
	public int addPurchaseDetails(PurchaseDetails pr);
	public ArrayList<Mobile> getMobileList();
	public ArrayList<Mobile> getMobileList(int min, int max);
	public Mobile updateMobileDetails(Mobile mob);

}
