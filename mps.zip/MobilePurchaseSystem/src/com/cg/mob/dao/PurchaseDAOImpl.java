package com.cg.mob.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.mob.dto.Mobile;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.PurchaseException;


public class PurchaseDAOImpl implements PurchaseDAO{
	Connection connection;
	
	public PurchaseDAOImpl() throws PurchaseException {
		connection= DBConnnection.getConnection();
	}
	public int generateId(){
		
		int id=0;
		try {
			Statement stmt=connection.createStatement();
			ResultSet rs=stmt.executeQuery("select id_gen.nextval from dual");
			if(rs.next())
				id=rs.getInt(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}
	
	
	@Override
	public int addPurchaseDetails(PurchaseDetails pr) {
		//int temp = 0;
		
		
		String sql="insert into purchasedetails values"+"(?, ? ,?, ? ,sysdate, ?)";
		try {
			PreparedStatement ps=connection.prepareStatement(sql);
			
			int id=generateId();
			//temp=id;
			ps.setInt(1,id);
			ps.setString(2, pr.getCustName());
			ps.setString(3, pr.getmailId());
			ps.setInt(4, pr.getMobileNo());
			ps.setInt(5, pr.getMobileId());
			int rc=ps.executeUpdate();
			if(rc==1)
			return id;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<Mobile> getMobileList() {
		
		return null;
	}

	@Override
	public ArrayList<Mobile> getMobileList(int min, int max) {
	
		return null;
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		
		return null;
	}

}
