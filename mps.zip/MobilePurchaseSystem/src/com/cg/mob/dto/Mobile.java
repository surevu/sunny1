package com.cg.mob.dto;

public class Mobile {
	
	private int MobileId;
	private String MobileName;
	private int MobileQuantity;
	private double MobilePrice;
	
	
	public int getMobileId() {
		return MobileId;
	}
	public void setMobileId(int mobileId) {
		MobileId = mobileId;
	}
	public String getMobileName() {
		return MobileName;
	}
	public void setMobileName(String mobileName) {
		MobileName = mobileName;
	}
	public int getMobileQuantity() {
		return MobileQuantity;
	}
	public void setMobileQuantity(int mobileQuantity) {
		MobileQuantity = mobileQuantity;
	}
	public double getMobilePrice() {
		return MobilePrice;
	}
	public void setMobilePrice(double mobilePrice) {
		MobilePrice = mobilePrice;
	}

}
