package com.cg.mob.dto;

import java.time.LocalDate;

public class PurchaseDetails {
	
	private int purchaseId;
	private int mobileId;
	private String custName;
	private int mobileNo;
	private String mailId;
	private LocalDate purchaseDate;
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mob) {
		this.mobileId = mob;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getmailId() {
		return mailId;
	}
	public void setmailId(String mailId) {
		this.mailId = mailId;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	

}
