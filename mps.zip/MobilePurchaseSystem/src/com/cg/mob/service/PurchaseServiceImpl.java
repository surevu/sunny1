package com.cg.mob.service;

import java.util.ArrayList;

import com.cg.mob.dao.PurchaseDAO;
import com.cg.mob.dao.PurchaseDAOImpl;
import com.cg.mob.dto.Mobile;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.PurchaseException;

public class PurchaseServiceImpl implements PurchaseService{
	
	PurchaseDAO dao;
	 public PurchaseServiceImpl() throws PurchaseException {
		dao=new PurchaseDAOImpl();
	 }
	 
	@Override
	public int addPurchaseDetails(PurchaseDetails pr) {
		int pi=dao.addPurchaseDetails(pr);
		// TODO Auto-generated method stub
		return pi;
	}
	@Override
	public ArrayList<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ArrayList<Mobile> getMobileList(int min, int max) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		// TODO Auto-generated method stub
		return null;
	}
}
			
			