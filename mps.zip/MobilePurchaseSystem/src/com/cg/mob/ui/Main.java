package com.cg.mob.ui;

import java.util.Scanner;

import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.PurchaseException;
import com.cg.mob.service.PurchaseService;
import com.cg.mob.service.PurchaseServiceImpl;


public class Main {
	
		private static Scanner sc;

		public static void main(String[] args) throws PurchaseException{
			
		PurchaseService service=new PurchaseServiceImpl();
			
			sc = new Scanner(System.in);
			int ch=0;
			do{
				System.out.println("\n-----------------------------\n Welcome to Smallc mobiles\n-----------------------------\n1. Add Purchase Details\n2. Display MobileList\n3. Display Mobile List between given price range\n4. Update Mobile Details\n5. Exit\nEnter Your Choice");
				ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				System.out.println("Enter customer Name : ");
				String name=sc.next();
				
				System.out.println("Enter phone no : ");
				int phn=sc.nextInt();
				
				System.out.println("Enter mailid : ");
				String mail=sc.next();
				
				System.out.println("Enter Mob id : ");
				int mb=sc.nextInt();
				
				
				PurchaseDetails pr=new PurchaseDetails();
				pr.setCustName(name);
				pr.setMobileNo(phn);
				pr.setmailId(mail);
				pr.setMobileId(mb);
				int pi=service.addPurchaseDetails(pr);
				System.out.println("Purchase details addeed .."+pi);
																		
				break;
			case 2:
				
				break;
			
			
			}
			
			}while(ch!=5);
			
			
			
		}

}
