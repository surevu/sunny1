package com.cg.mypaymentapp.main;

import java.util.List;
import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transact;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Client {
	static Scanner sc;
	public static void main(String[] args) throws InvalidInputException {
		
		WalletService service=new WalletServiceImpl();
		
		
		 sc=new Scanner(System.in);
		int ch=0;
		
		do{
			System.out.println("\nVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
			System.out.println("		Mobile Wallet				");
			System.out.println("VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV");
			System.out.println(" 1.Create Account");
			System.out.println(" 2.Show Balance");
			System.out.println(" 3.Deposit");
			System.out.println(" 4.Withdraw");
			System.out.println(" 5.Fund Transfer");
			System.out.println(" 6.Fund Transcations");
			
			System.out.println("\nEnter Your Choice :\n");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:															//Create Account
				System.out.println("Please Enter Your Mobile Number");
				String custMobNo=sc.next();	
				if(service.ValidateMobNo(custMobNo)){		
					System.out.println("Please Enter Your Name");
					String custName=sc.next();
					
					if(service.ValidateName(custName)){
						System.out.println("Please Enter Money you wanted to add");
						float money=sc.nextFloat();
				
						try{if(service.ValidateAmount(money)){
							Customer cust = null;
				
							try{
								if(service.checkAccount(custMobNo)==null){
				
									cust = service.createAccount(custMobNo,custName, money);
									
									System.out.println(cust);
									System.out.println("Registered successfully !! ");
									}	
								}
									catch (InvalidInputException e) {
										System.out.println(e.getMessage());
									}
				
						}else
							System.out.println("Enter money greater than zero ");
						}
						catch(InvalidInputException e){
							System.out.println(e.getMessage());
						}
					}else
					System.out.println("Enter Valid Name with only aplhabets and Name Starting with Capital Letter ");
				}
				else
					System.out.println("Enter Valid 10 digit number starting with 6/7/8/9");
				
				break;
			
			case 2:															//show Balance
				System.out.println("Please Enter Your Mobile Number");
				String custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
						Customer customer=service.showBalance(custMobNo1);
						System.out.println("Hi "+customer.getName()+", your balance is "+customer.getBalance() +" !!");
						}
					else
						throw new InvalidInputException("Enter Ten Digit Number starting with 6/7/8/9  ");
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				
				break;
				
			
				case 3:
				System.out.println("Please Enter Your Mobile Number");
				custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
					 Customer customer=service.showBalance(custMobNo1);
					 
					 System.out.println("Hi "+customer.getName()+", your current balance is "+customer.getBalance() +" !!");
					 System.out.println("Please Enter the amount you want to deposit ");
					 
					 float dep=sc.nextFloat();
					 if(service.ValidateAmount(dep)){
					 customer=service.depositAmount(custMobNo1, dep);
					 
					 System.out.println("Hi "+customer.getName()+", your updated balance is "+customer.getBalance() +" !!");
					}
					 else
						 System.out.println("Deposit amount must greater than zero");
					}
					else
						System.out.println("Enter  Ten Digit Mobile Number  ");
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
					
				 break;
				 
				case 4:
				System.out.println("Please Enter Your Mobile Number");
				custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
					 Customer customer=service.showBalance(custMobNo1);
					
					 System.out.println("Hi "+customer.getName()+", your current balance is "+customer.getBalance() +"  !!");
					 System.out.println("Please Enter the amount you want to withdraw ");
					 float withdraw=sc.nextFloat();
					 if(service.ValidateAmount(withdraw)){
					 try {
						customer=service.withdrawAmount(custMobNo1, withdraw);
					} catch (InsufficientBalanceException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
						break;
					}
					
					 System.out.println("Hi "+customer.getName()+", your updated balance is "+customer.getBalance() +"  !!");
					}else
					System.out.println("Withdrwa must be greater than zero");	
					}
					else 
						System.out.println("Enter Ten Digit Mobile Number  ");
				} catch (InvalidInputException e) {
						System.out.println(e.getMessage());
				
				}
				 break;
				 
				 
			case 5:
				System.out.println("Please Enter Your Mobile Number");
				String custMobNoS=sc.next();
				try {
					if(service.ValidateMobNo(custMobNoS)){
						service.showBalance(custMobNoS);
						Customer customer=service.showBalance(custMobNoS);
						
						System.out.println("Hi "+customer.getName()+", your current balance is "+customer.getBalance() +"  !!");
						System.out.println("Please Enter the mobile number  you want to transfer money ");
						String custMobNoT=sc.next();
						if(service.ValidateMobNo(custMobNoT)){
							service.showBalance(custMobNoT);
						System.out.println("Please Enter amount to be transferred ");
						float ft=sc.nextFloat();
						if(service.ValidateAmount(ft)){
							
						customer=service.fundTransfer(custMobNoS, custMobNoT, ft);
						
						System.out.println("Hi "+customer.getName()+",Amount Transferred successfully and\n Your updated balance is "+customer.getBalance() +"  !!");
					}else
						System.out.println("Enter Transfer amount greater than zero");
						}
						else
							System.out.println("Enter 10 digit valid Mobile Number");}
					else
						System.out.println("Enter  Ten Digit valid Mobile Number");
				} catch (InvalidInputException e) {
					System.out.println(e.getMessage());
					
				}
				
				 break;
				 
			case 6:
				
				List<Transact> list=service.getAll();
				for(Transact t:list)
					System.out.println(t.getTr());
				
				break;
			}
			
		}while(ch!=7);
		
System.out.println("Thank You !!");
	}

}
