package com.cg.mypaymentapp.repo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.mypaymentapp.beans.Customer;


public class WalletRepoImpl implements WalletRepo {

	EntityManager manager;
	 public WalletRepoImpl() {
		 

			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAQ");
			manager =emf.createEntityManager();
	 }
		
	
	@Override
	public boolean save(Customer customer) {
		
		if(customer!=null){
		manager.getTransaction().begin();
		manager.persist(customer);
		manager.getTransaction().commit();
		return true;
		}
		
		return false;
	
	}
	@Override
	public Customer findOne(String mobileNo) {
		
		//Query querySearch =manager.createQuery("FROM Customer WHERE mobileNo=:mobN");
		//querySearch.setParameter("mobN", mobileNo);
		//querySearch.executeUpdate();
		//Customer mobSearch=(Customer) querySearch.getSingleResult();
		Customer mobSearch=manager.find(Customer.class, mobileNo);
		//if(mobSearch!=null)
		return mobSearch;
		//manager.
		//return null;
	}
	
	
	
}
