package com.cg.mypaymentapp.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;


import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transact;


public class WalletRepoImpl implements WalletRepo {

	EntityManager manager;
	 public WalletRepoImpl() {
		 

			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAQ");
			manager =emf.createEntityManager();
	 }
		
	
	@Override
	public boolean save(Customer customer) {
		
		if(customer!=null){
		manager.getTransaction().begin();
		manager.persist(customer);
		manager.getTransaction().commit();
		return true;
		}
		
		return false;
	
	}
	@Override
	public Customer findOne(String mobileNo) {
		
		
		Customer custSearch=manager.find(Customer.class, mobileNo);
	
		return custSearch;
		
	}


	@Override
	public boolean allTransactions(String s) {
		
		int i=(int) (100*Math.random());
		Transact t=new Transact(i, s);
		
		manager.getTransaction().begin();
		manager.persist(t);
		manager.getTransaction().commit();
		return true;
	}
	
	public List<Transact> getAll(){
		List<Transact> list= new ArrayList<Transact>();
		TypedQuery<Transact> sql=manager.createQuery("select p from Transact p",Transact.class);
		
		list=sql.getResultList();
		
		
		return list;
		
		
		
		
		
		
	}
	
	
}
