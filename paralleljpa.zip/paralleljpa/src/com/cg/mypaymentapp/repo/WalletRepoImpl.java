package com.cg.mypaymentapp.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;


import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transact;


public class WalletRepoImpl implements WalletRepo {

	EntityManager manager;
	 public WalletRepoImpl() {
		 

			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAQ");
			manager =emf.createEntityManager();
	 }
		
	
	@Override
	public boolean save(Customer customer) {   //receives customer object from service layer and sends it to database
		
		if(customer!=null){
		manager.getTransaction().begin();		//transaction begin
		manager.persist(customer);				// sends it to data base
		manager.getTransaction().commit();		//end transaction
		return true;							// successful transaction
		}
		
		return false;							//unsuccessful transaction
	
	}
	@Override
	public Customer findOne(String mobileNo) { 						//receives mobile no from service layer
		
		
		Customer custSearch=manager.find(Customer.class, mobileNo); //saerches in database
	
		return custSearch;											//returns it to database
		
	}


	@Override
	public boolean allTransactions(String s) {						//sends transactions to database		
		
		int i=1;
		Transact t=new Transact(i, s);								//creating transaction object
		
		manager.getTransaction().begin();
		manager.persist(t);											//sends it to database
		manager.getTransaction().commit();
		return true;
	}
	
	public List<Transact> getAll(){									//receives trasactions from database
		List<Transact> list= new ArrayList<Transact>();				//creating list to store all transactions
		TypedQuery<Transact> sql=manager.createQuery("select p from Transact p",Transact.class); //
		
		list=sql.getResultList();
		
		
		return list;
		
		
		
		
		
		
	}
	
	
}
