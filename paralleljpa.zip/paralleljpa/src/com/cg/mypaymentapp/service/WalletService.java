package com.cg.mypaymentapp.service;
import java.math.BigDecimal;
import java.util.List;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transact;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;


public interface WalletService {

public Customer createAccount(String custMobNo, String custName, float money) throws InvalidInputException;
public Customer showBalance (String mobileno) throws InvalidInputException;
public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, float amount) throws InvalidInputException;
public Customer depositAmount (String mobileNo,float amount ) throws InvalidInputException;
public Customer withdrawAmount(String mobileNo, float amount) throws InsufficientBalanceException, InvalidInputException;
public Customer checkAccount(String mobileno) throws InvalidInputException;


public boolean ValidateName(String name) throws InvalidInputException;
public boolean ValidateMobNo(String MobNo) throws InvalidInputException;
public boolean ValidateAmount(float money) throws InvalidInputException;

public List<Transact> getAll();



}
