package com.cg.mypaymentapp.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transact;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {

	WalletRepo wrepo;
	
	public WalletServiceImpl() {
		wrepo=new WalletRepoImpl();
	}
	
	
	@Override
	public Customer createAccount(String mobileno, String name,
			float amount) throws InvalidInputException{
		
		Customer c=new Customer( mobileno,name, amount);
		if(wrepo.save(c)){
			return c;
		}
		
		return null;
		
	}

	@Override
	public Customer showBalance(String mobileno) throws InvalidInputException {
		
		Customer cust=wrepo.findOne(mobileno);
		if(cust==null)
			throw new InvalidInputException("Number not registered");
		else
		return cust;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			float amount) throws InvalidInputException {
		
		Customer cust1=wrepo.findOne(sourceMobileNo);
		if(cust1==null)
			throw new InvalidInputException("Number not registered");
		
		float currentbal=cust1.getBalance();
		Customer cust2=wrepo.findOne(targetMobileNo);
		if(cust2==null)
			throw new InvalidInputException("Number not registered");
		float currentbal2=cust2.getBalance();
		if(sourceMobileNo.equals(targetMobileNo))
			throw new InvalidInputException("Both Numbers are same");
		if(amount>20000)
			throw new InvalidInputException("Transfet limit is 20,000");
		
		if(currentbal<amount)
			throw new InvalidInputException("Your account balance is less than amount you are transferring");
		
		currentbal2= currentbal2 + amount;
		currentbal= currentbal - amount;
		
		cust1.setBalance(currentbal);
		wrepo.save(cust1);	
		
		cust2.setBalance(currentbal2);		
		wrepo.save(cust2);
		
		Customer cust3=wrepo.findOne(sourceMobileNo);
		
		String s="Transferred amount "+amount+" into "+ targetMobileNo +" from "+sourceMobileNo;
		wrepo.allTransactions(s);
		
		return cust3;
	}

	@Override
	public Customer depositAmount(String mobileNo, float amount) throws InvalidInputException {
		
		Customer cust=wrepo.findOne(mobileNo);
		if(cust==null)
			throw new InvalidInputException("Number not registered");
		
		float currentbal=cust.getBalance();
		
		float newbal= currentbal + amount;
		cust.setBalance(newbal);
		wrepo.save(cust);
		
		Customer cust1=wrepo.findOne(mobileNo);
		
		String s="Deposited amount "+amount+" into "+mobileNo;
		wrepo.allTransactions(s);
		return cust1;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, float amount) throws InsufficientBalanceException, InvalidInputException {
		Customer cust=wrepo.findOne(mobileNo);
		if(cust==null)
			throw new InvalidInputException("Number not registered");
		
		float currentbal=cust.getBalance();
		if(currentbal >amount){
			float newbal= currentbal-amount;
			
			cust.setBalance(newbal);
			wrepo.save(cust);
		
			Customer cust1=wrepo.findOne(mobileNo);
		
			String s="Withdrawn amount "+amount+" from "+mobileNo;
			wrepo.allTransactions(s);
		return cust1;
		}
		else
			throw new InsufficientBalanceException("Current balance is lesser than Withdraw Ammount ");
	}

	@Override
	public boolean ValidateName(String name) throws InvalidInputException {
		if(name==null)
			throw new InvalidInputException("Name field cannot be empty");
		Pattern pat=Pattern.compile("[A-Z][A-Za-z ]{2,20}");
		Matcher mat=pat.matcher(name);
		return mat.matches();
	}

	@Override
	public boolean ValidateMobNo(String MobNo) throws InvalidInputException {
		if(MobNo==null)
			throw new InvalidInputException("Number connot be zero");
		Pattern pat=Pattern.compile("[6-9][0-9]{9}");
		Matcher mat=pat.matcher(MobNo);
		return mat.matches();
		
	}

	@Override
	public boolean ValidateAmount(float amount) throws InvalidInputException {
		
	if(amount>0&&amount<100000)
		return true;
	return false;
	}


	@Override
	public Customer checkAccount(String mobileno) throws InvalidInputException {
		Customer cust=wrepo.findOne(mobileno);
		if(cust!=null)
			throw new InvalidInputException("Number already registered");
		else
		return null;
		
	}


	@Override
	public List<Transact> getAll() {
		// TODO Auto-generated method stub
		return wrepo.getAll();
	}

}
