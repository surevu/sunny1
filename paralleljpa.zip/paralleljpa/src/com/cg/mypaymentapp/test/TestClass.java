package com.cg.mypaymentapp.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class TestClass {

	@Test
	public void test_validateName_v1() throws InvalidInputException {
		String name="aaaa12@";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateName(name);
		assertEquals(false, result);
	}
	@Test
	public void test_validateName_v2() throws InvalidInputException {
		String name="Sunny";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateName(name);
		assertEquals(true, result);
	}
	
	@Test
	public void test_validateName_v3() throws InvalidInputException {
		String name="sunny";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateName(name);
		assertEquals(false, result);
	}
	
	@Test
	public void test_validateMobNo_v1() throws InvalidInputException {
		String name="0123456789";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(false, result);	
	}	
	@Test
	public void test_validateMobNo_v2() throws InvalidInputException {
		String name="9123456789";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(true, result);	
	}	
	@Test
	public void test_validateMobNo_v3() throws InvalidInputException {
		String name="01234";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(false, result);	
	}	
	@Test
	public void test_validateMobNo_v4() throws InvalidInputException {
		String name="hgfdgfd";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(false, result);	
	}
	
	@Test
	public void test_validateAmount_v1() throws InvalidInputException {
		
		WalletService w=new WalletServiceImpl();
		float amount=new Float(500);
		boolean result=w.ValidateAmount(amount);
		assertEquals(false, result);	
	}	
	
	
	
	
	
	

}
