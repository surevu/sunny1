package com.cg.mypaymentapp.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;
import org.junit.BeforeClass;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class TestClass {
	
	static Customer cust;
	static WalletService ws;

	@BeforeClass
	public static void init(){
		System.out.println("In Before Class..");
		cust=new Customer();
		ws=new WalletServiceImpl();

	}
	
	@Test
	public void  test_createAccount_1() throws InvalidInputException {
			assertNotNull(ws.createAccount("8989734945", "sunny", 963));
	}
	
	@Test
	public void  test_showbalance() throws InvalidInputException {
			assertNotNull(ws.showBalance("9989334999"));
	}
	@Test
	public void  test_depositbalance() throws InvalidInputException {
			assertNotNull(ws.depositAmount("9989334999",45));
	}
	@Test
	public void  test_withdraw() throws InvalidInputException, InsufficientBalanceException {
			assertNotNull(ws.withdrawAmount("9989334999", 963));
	}
	
	@Test
	public void  test_fundtransfer() throws InvalidInputException {
			assertNotNull(ws.fundTransfer("8686682001", "9989334999", 963));
	}
	
	
	@Test
	public void test_createAccount_2() throws InvalidInputException
	{
		
		assertTrue("account created",(ws.createAccount("8989634945", "sunny", 963)!=null));
	}
	
	@Test
	public void test_validateName_v1() throws InvalidInputException {
		String name="aaaa12@";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateName(name);
		assertEquals(false, result);
	}
	@Test
	public void test_validateName_v2() throws InvalidInputException {
		String name="Sunny";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateName(name);
		assertEquals(true, result);
	}
	
	@Test
	public void test_validateName_v3() throws InvalidInputException {
		String name="sunny";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateName(name);
		assertEquals(false, result);
	}
	
	@Test
	public void test_validateMobNo_v1() throws InvalidInputException {
		String name="0123456789";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(false, result);	
	}	
	@Test
	public void test_validateMobNo_v2() throws InvalidInputException {
		String name="9123456789";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(true, result);	
	}	
	@Test
	public void test_validateMobNo_v3() throws InvalidInputException {
		String name="01234";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(false, result);	
	}	
	@Test
	public void test_validateMobNo_v4() throws InvalidInputException {
		String name="hgfdgfd";
		WalletService w=new WalletServiceImpl();
		boolean result=w.ValidateMobNo(name);
		assertEquals(false, result);	
	}
	
	@Test
	public void test_validateAmount_v1() throws InvalidInputException {
		
		WalletService w=new WalletServiceImpl();
		float amount=new Float(500);
		boolean result=w.ValidateAmount(amount);
		assertEquals(true, result);	
	}	
	
	
	
	
	
	

}
