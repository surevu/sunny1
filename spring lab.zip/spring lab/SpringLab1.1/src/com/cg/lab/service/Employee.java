package com.cg.lab.service;

public class Employee {
	int employeeId;
	String employeeName;
	double salary;
	String bussinessUnit;
	int employeeAge;
	public int getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public String getBussinessUnit() {
		return bussinessUnit;
	}
	public int getEmployeeAge() {
		return employeeAge;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setBussinessUnit(String bussinessUnit) {
		this.bussinessUnit = bussinessUnit;
	}
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

}
