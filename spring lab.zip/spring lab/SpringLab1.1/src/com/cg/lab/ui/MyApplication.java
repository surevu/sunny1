package com.cg.lab.ui;

import java.util.Scanner;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab.service.Employee;

public class MyApplication {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Nmae,id,age,salary,bussinessunit in this oreder ");
		String en=sc.next();
		int ei=sc.nextInt();
		int ea=sc.nextInt();
		double es=sc.nextDouble();
		String ebu=sc.next();
		
		
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		Employee emp1=(Employee) app.getBean("emp");
		emp1.setEmployeeName(en);
		emp1.setBussinessUnit(ebu);
		emp1.setEmployeeAge(ea);
		emp1.setEmployeeId(ei);
		emp1.setSalary(es);
		
		System.out.println("Employee Name\t: "+emp1.getEmployeeName());
		System.out.println("Employee Id\t: "+emp1.getEmployeeId());
		System.out.println("Employee Age\t: "+emp1.getEmployeeAge());
		System.out.println("Employee BU\t: "+emp1.getBussinessUnit());
		System.out.println("Employee Salary\t: "+emp1.getSalary());
		
	}

}
