package com.cg.lab.service;

public class Employee {
	int employeeId;
	String employeeName;
	double salary;
	SBU bussinessUnit;
	
	public SBU getBussinessUnit() {
		return bussinessUnit;
	}
	public void setBussinessUnit(SBU bussinessUnit) {
		this.bussinessUnit = bussinessUnit;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public void getSbudetails(){
		System.out.println("Employee Details : \n____________________________________________________________________\n");
		System.out.print("Employee  [  Employee Name  : "+employeeName);
		System.out.print(",  Employee Id  : "+employeeId);
		System.out.print(",  Employee Salary  : "+salary+"]\n");
		
		System.out.print("sbu details sbu [  SBU Code : "+bussinessUnit.getSbuId());
		System.out.print(", SBU Name : "+bussinessUnit.getSbuName());
		System.out.print(", SBU Head : "+bussinessUnit.getSbuHead()+" ] ");
		
		
		
		
	}
	
}
