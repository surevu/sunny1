package com.cg.lab.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab.service.Employee;
import com.cg.lab.service.SBU;

public class MyApplication {

	public static void main(String[] args) {
		
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		Employee emp1=(Employee) app.getBean("emp",Employee.class);
		//SBU sbu1=(SBU) app.getBean(SBU.class);
		//emp1.setBussinessUnit(sbu1);
		emp1.getSbudetails();
		
	}

}
