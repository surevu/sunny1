package com.cg.lab.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab.service.Employee;
import com.cg.lab.service.SBU;

public class MyApplication {

	public static void main(String[] args) {
		
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		
		SBU s=(SBU) app.getBean("sbu");
		//SBU sbu1=(SBU) app.getBean(SBU.class);
		//emp1.setBussinessUnit(sbu1);
	s.getSbudetails();
		
	}

}
