package com.cg.springlabtwo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springlabtwo.dto.Trainee;
import com.cg.springlabtwo.service.TrService;


@Controller
public class TController {
	@Autowired
	TrService trservice;
	
	@RequestMapping(value="loginpage")
	public String loginPage(){
		
		return "login";
	}
	
	@RequestMapping(value="tms")
	public String menu(){
		
		return "menu";
		
	}
	
	@RequestMapping(value="add")
	public String addTr(@ModelAttribute("tr") Trainee tra,Map<String,Object> map){
		
		
		List<String> myList=new ArrayList<>();
		List<String> myList1=new ArrayList<>();
		myList.add("JAVA");
		myList.add(".NET");
		myList.add("C++");
		myList1.add("Chennai");
		myList1.add("Hyderabad");
		myList1.add("Mumbai");
		myList1.add("Pune");
		
		map.put("domain",myList);
		map.put("loc",myList1);
		
		return "addTrDetails";
	}
	
	
	@RequestMapping(value="success",method=RequestMethod.POST)
	public String addSuccess(@ModelAttribute("tr") Trainee tra,Map<String, Object> map){
		
		trservice.addTrainee(tra);
		System.out.println(tra);
		
		return "addSuccessPage";
	
		
	}
	@RequestMapping(value="delete")
	public String delete(@ModelAttribute("tr1") Trainee tra){
		
		return "delete";
		
	}
	@RequestMapping(value="deletesuccess",method=RequestMethod.POST)
	public ModelAndView delete1(@ModelAttribute("tr1") Trainee tra){
		System.out.println(tra.getTrId());
		Trainee tr=trservice.search(tra.getTrId());
		System.out.println(tr);
		
		return new ModelAndView("deletesuccess", "tem", tr);
		
	}
	
	
	@RequestMapping(value="deletesuccesspage",method=RequestMethod.POST)
	public String delete2(@ModelAttribute("tr1") Trainee tra){
		
		System.out.println(tra.getTrId());
		trservice.delte(tra.getTrId());
		System.out.println("trservice.delte(tra.getTrId())");
		
		return "deletesuccesspage";
		
	}
	
	@RequestMapping(value="show")
	public String show(@ModelAttribute("tr2") Trainee tra){
		
		return "show";
		
	}
	
	@RequestMapping(value="showid",method=RequestMethod.POST)
	public ModelAndView show1(@ModelAttribute("tr2") Trainee tra){
		System.out.println(tra.getTrId());
		Trainee tr=trservice.search(tra.getTrId());
		System.out.println(tr);
		
		return new ModelAndView("showid", "tem", tr);
		
	}
	
	
}
