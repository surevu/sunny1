package com.cg.springlabtwo.dao;

import com.cg.springlabtwo.dto.Trainee;

public interface TrDao {
	public void addTrainee(Trainee tr);
	public void delte(int id);
	public Trainee search(int id);
		
	
}
