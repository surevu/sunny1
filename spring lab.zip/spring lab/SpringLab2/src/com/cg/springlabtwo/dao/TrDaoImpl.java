package com.cg.springlabtwo.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springlabtwo.dto.Trainee;



@Repository("trdao")
public class TrDaoImpl implements TrDao {
	
	
	@PersistenceContext
	EntityManager em;

	@Override
	public void addTrainee(Trainee tr) {
		em.persist(tr);
		em.flush();
		
	}

	@Override
	public void delte(int id) {
		Query query=em.createQuery("DELETE Trainee WHERE TrId=:trid");
		query.setParameter("trid", id);
		query.executeUpdate();
		
	}

	@Override
	public Trainee search(int id) {
		Query query=em.createQuery("FROM Trainee WHERE TrId=:trid1");
		query.setParameter("trid1", id);
		Trainee Tr=(Trainee) query.getResultList().get(0);
		return Tr;
	}

}
