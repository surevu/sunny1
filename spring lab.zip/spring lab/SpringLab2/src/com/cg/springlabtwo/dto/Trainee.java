package com.cg.springlabtwo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name="traineetab")
public class Trainee {
	
	@Id
	@Column(name="tr_id")
	Integer TrId;
	@Column(name="tr_name")
	String TrName;
	@Column(name="tr_loc")
	String TrLoc;
	@Column(name="tr_domain")
	String TrDomain;
	
	public Trainee() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Trainee(Integer trId, String trName, String trLoc, String trDomain) {
		super();
		TrId = trId;
		TrName = trName;
		TrLoc = trLoc;
		TrDomain = trDomain;
	}
	@Override
	public String toString() {
		return "Trainee [TrId=" + TrId + ", TrName=" + TrName + ", TrLoc="
				+ TrLoc + ", TrDomain=" + TrDomain + "]";
	}
	public Integer getTrId() {
		return TrId;
	}
	public void setTrId(Integer trId) {
		TrId = trId;
	}
	public String getTrName() {
		return TrName;
	}
	public void setTrName(String trName) {
		TrName = trName;
	}
	public String getTrLoc() {
		return TrLoc;
	}
	public void setTrLoc(String trLoc) {
		TrLoc = trLoc;
	}
	public String getTrDomain() {
		return TrDomain;
	}
	public void setTrDomain(String trDomain) {
		TrDomain = trDomain;
	}
	
	
	
	
	

}
