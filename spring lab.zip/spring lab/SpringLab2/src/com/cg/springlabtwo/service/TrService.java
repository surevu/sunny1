package com.cg.springlabtwo.service;

import com.cg.springlabtwo.dto.Trainee;

public interface TrService {
	public void addTrainee(Trainee tr);
	public void delte(int id);
	public Trainee search(int id);
}
