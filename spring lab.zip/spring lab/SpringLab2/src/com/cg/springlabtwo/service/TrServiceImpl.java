package com.cg.springlabtwo.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springlabtwo.dao.TrDao;
import com.cg.springlabtwo.dto.Trainee;


@Service("trservice")
@Transactional
public class TrServiceImpl implements TrService {
	
	@Autowired
	TrDao trdao;
	
	@Override
	public void addTrainee(Trainee tr) {
		
		trdao.addTrainee(tr);
		
	}

	@Override
	public void delte(int id) {
		trdao.delte(id);
		
	}

	@Override
	public Trainee search(int id) {
		// TODO Auto-generated method stub
		return trdao.search(id);
	}

}
